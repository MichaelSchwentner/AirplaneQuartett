open class Cpu(var name:String) {

    open fun vorstellungCpu(){
        println("\n✠ ✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠ ✠\n" +
                "✠                      Airplane ✈️️ 1.0 Quartet®                             ✠\n" +
                "✠                            ___________                                    ✠\n" +
                "✠                                 |                                         ✠\n" +
                "✠                            _   _|_   _                                    ✠\n" +
                "✠                           (_)-/   \\-(_)                                   ✠\n" +
                "✠    _                         /\\___/\\                         _            ✠\n" +
                "✠   (_)_______________________( ( . ) )_______________________(_) ®xcub     ✠\n" +
                "✠                              \\_____/                                      ✠")
        println("✠ ✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠ ✠\n")
        println("You are currently playing the Airplane ✈️️ 1.0 Quartet®. Press Enter to start the Game!")
    }
    open fun vorstellungEser(){
        println("Hi, I'm $name \uD83E\uDD16, the artificial intelligence you're going to play against. Good luck!\n" +
                "✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠✠"
        )
    }
}