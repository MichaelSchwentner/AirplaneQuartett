open class Flugzeuge(var name:String, var geschwindigkeit:Double, var laenge:Double, var spannweite:Double, var typ:String, var land:String) {

}